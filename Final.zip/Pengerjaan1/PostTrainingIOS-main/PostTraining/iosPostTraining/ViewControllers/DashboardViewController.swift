//
//  DashboardViewController.swift
//  iosPostTraining
//
//  Created by prk on 27/04/23.
//

import UIKit

class DashboardViewController: UIViewController {

    @IBOutlet weak var LogoIIV: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        LogoIIV.image = UIImage(named: "Logo")
        // Do any additional setup after loading the view.
    }
    
    @IBAction func manage_clicked(_ sender: Any) {
//        if let nextView = storyboard?
//            .instantiateViewController(withIdentifier: "HomeViewController") {
//            navigationController?.pushViewController(nextView, animated: true)
//        }
    }
    
    
    @IBAction func logout_clicked(_ sender: Any) {
//        if let nextView = storyboard?
//            .instantiateViewController(withIdentifier: "LoginViewController") {
//            navigationController?.pushViewController(nextView, animated: true)
//        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
