//
//  HomeViewController.swift
//  iosPostTraining
//
//  Created by prk on 19/04/23.
//

import UIKit
import CoreData

class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var arrOfType = [String]()
    var arrOfName = [String]()
    var arrOfPage = [String]()
    
    
    @IBOutlet weak var nameTxt: UITextField!
    @IBOutlet weak var typeTxt: UITextField!
    @IBOutlet weak var dataTv: UITableView!
    var context:NSManagedObjectContext!
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // jumlah data
        return arrOfName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // tiap rownya bakal diisi apa
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! ViewTableTableViewCell
        
        cell.nameTxt.text = arrOfName[indexPath.row]
        
        cell.typeTxt.text = arrOfType[indexPath.row]
        
        cell.pageTxt.text = arrOfPage[indexPath.row]
        
        cell.updateHandler = {
            self.updateData(cell: cell, indexPath: indexPath)
        }
        
        cell.deleteHandler = {
            self.deleteData(cell: cell, indexPath: indexPath)
        }
        
        return cell
    }
    
    func loadData() {
        // load data berdasarkan array yang ada
        arrOfName.removeAll()
        arrOfType.removeAll()
        arrOfPage.removeAll()
        
        let Request = NSFetchRequest<NSFetchRequestResult>(entityName: "Books")
        do {
            let result = try context.fetch(Request) as! [NSManagedObject]
            
            for data in result {
                arrOfType.append(data.value(forKey: "book_type") as! String)
                arrOfName.append(data.value(forKey: "book_name") as! String)
                arrOfPage.append(data.value(forKey: "book_page") as! String)
                print(data.value(forKey: "book_name") as! String)
            }
            dataTv.reloadData()
        } catch {
            print("error kia")
        }
    }
    
    func updateData(cell : ViewTableTableViewCell, indexPath : IndexPath) {
        let oldName = arrOfName[indexPath.row]
        let oldType = arrOfType[indexPath.row]
        
        let newName = cell.nameTxt.text!
        let newType = cell.typeTxt.text!
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Books")
        
        request.predicate = NSPredicate(format: "book_name == %@ AND book_type == %@", oldName, oldType)
        
        do {
            let results = try context.fetch(request) as! [NSManagedObject]
            
            for data in results {
                data.setValue(newName, forKey: "book_name")
                data.setValue(newType, forKey: "book_type")
            }
            
            try context.save()
            loadData()
            
        } catch {
            print("Something went wrong")
        }
        
    }
    
    func deleteData(cell : ViewTableTableViewCell, indexPath : IndexPath) {
        let name = arrOfName[indexPath.row]
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Books")
        request.predicate = NSPredicate(format: "book_name == %@", name)
        
        do {
            let results = try context.fetch(request) as! [NSManagedObject]
            
            for data in results {
                context.delete(data)
            }
            
            try context.save()
            loadData()
        } catch {
            print("Something went wrong")
        }
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        context = appDelegate.persistentContainer.viewContext
        dataTv.delegate = self
        dataTv.dataSource = self
        loadData()
        // Do any additional setup after loading the view.
    }
    

    
    
    @IBAction func insertClicked(_ sender: Any) {
        
        let name = nameTxt.text!
        let type = typeTxt.text!
        
        if (name.isEmpty || type.isEmpty) {
            return
        }
        
        let entity = NSEntityDescription.entity(forEntityName: "Books", in: context)
        let newBook = NSManagedObject(entity: entity!, insertInto: context)
        
        newBook.setValue(name, forKey: "book_name")
        newBook.setValue(type, forKey: "book_type")
        
        let page = String(name.count * 5) + " page(s)"
        newBook.setValue(page, forKey: "book_page")
        print(name.count)
        
        do {
            try context.save()
            loadData()
        } catch {
            print("Error Insert")
        }
        
    }
    
    // update
    // reload data
   
    
    // delete
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
