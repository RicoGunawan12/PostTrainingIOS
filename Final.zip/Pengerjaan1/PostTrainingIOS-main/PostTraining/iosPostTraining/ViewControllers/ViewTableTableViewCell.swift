//
//  ViewTableTableViewCell.swift
//  iosPostTraining
//
//  Created by prk on 19/04/23.
//

import UIKit

class ViewTableTableViewCell: UITableViewCell {

    
    
    @IBOutlet weak var typeTxt: UITextField!
    @IBOutlet weak var nameTxt: UITextField!
    
    
    @IBOutlet weak var pageTxt: UILabel!
    
    var updateHandler = {
        
    }
    
    var deleteHandler = {
        
    }
    
    @IBAction func updateClicked(_ sender: Any) {
        updateHandler()
    }
    
    @IBAction func deleteClicked(_ sender: Any) {
        deleteHandler()
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
