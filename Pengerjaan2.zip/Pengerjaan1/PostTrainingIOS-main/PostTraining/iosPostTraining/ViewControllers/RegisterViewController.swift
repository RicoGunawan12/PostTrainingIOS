//
//  RegisterViewController.swift
//  iosPostTraining
//
//  Created by prk on 19/04/23.
//

import UIKit
import CoreData

class RegisterViewController: UIViewController {


    
    @IBOutlet weak var usernameTxt: UITextField!
    
    @IBOutlet weak var passwordTxt: UITextField!
    
    @IBOutlet weak var confTxt: UITextField!
    
    @IBOutlet weak var firstNum: UILabel!
    
    @IBOutlet weak var secNum: UILabel!
    
    @IBOutlet weak var resultTxt: UITextField!
    
    var context:NSManagedObjectContext!
    
    var captcha : Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let num1 = Int.random(in: 1...10)
        let num2 = Int.random(in: 1...10)
        captcha = num1 + num2
        firstNum.text = String(num1)
        secNum.text = String(num2)
        
        context = appDelegate.persistentContainer.viewContext
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func registerClicked(_ sender: Any) {
        // ambil value dari text field
        // masukin db
        
        // let -> immutable
        // var -> mutable
        
        let username = usernameTxt.text! // tanda seru artinya paksa ada isi
        let password = passwordTxt.text! // tanda seru artinya paksa ada isi
        let conf = confTxt.text!
        
        if (username.isEmpty || password.isEmpty || conf.isEmpty) {
            return
        }
        if (username.count < 3) {
            return
        }
        if (password != conf) {
            return
        }
        if (Int(resultTxt.text ?? "") != captcha) {
            return
        }
        
        // bikin entity
        // bikin new user
        // insert data
        let entity = NSEntityDescription.entity(forEntityName: "Users", in: context)!
        
        let newUser = NSManagedObject(entity: entity, insertInto: context)
        
        newUser.setValue(username, forKey: "username")
        newUser.setValue(password, forKey: "password")
        
        do {
            try context.save()
            // redirect to other page
//            let nextView = LoginViewController()
//            navigationController?.pushViewController(nextView, animated: <#T##Bool#>)
            
            if let nextView = storyboard?
                .instantiateViewController(withIdentifier: "LoginViewController") {
                navigationController?.pushViewController(nextView, animated: true)
            }
        }
        catch{
            print("insert failed")
        }
    }
    
    /*
     
     // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
